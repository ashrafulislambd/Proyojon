import { useState } from 'react';
import { Link } from 'react-router';
import { useApp } from '../context/AppContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Progress } from '../components/ui/progress';
import { Calendar, DollarSign, CheckCircle, Clock, AlertCircle, ShoppingCart } from 'lucide-react';
import { format, addDays, addWeeks, addMonths } from 'date-fns';
import { toast } from 'sonner';

interface PaymentInstallment {
  orderId: string;
  installmentNumber: number;
  totalInstallments: number;
  amount: number;
  dueDate: Date;
  status: 'paid' | 'upcoming' | 'overdue';
  orderTotal: number;
  items: string[];
}

export function Repayments() {
  const { orders } = useApp();
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'upcoming' | 'paid'>('all');

  // Generate payment schedule for all orders with installments
  const generatePaymentSchedule = (): PaymentInstallment[] => {
    const schedule: PaymentInstallment[] = [];

    orders.forEach(order => {
      if (order.installments) {
        const orderDate = new Date(order.date);
        const { amount, remaining, frequency } = order.installments;
        const totalInstallments = remaining;

        for (let i = 0; i < totalInstallments; i++) {
          let dueDate: Date;
          
          switch (frequency) {
            case 'bi-weekly':
              dueDate = addWeeks(orderDate, i * 2);
              break;
            case 'weekly':
              dueDate = addWeeks(orderDate, i);
              break;
            case 'monthly':
              dueDate = addMonths(orderDate, i);
              break;
            default:
              dueDate = addDays(orderDate, i * 7);
          }

          const today = new Date();
          today.setHours(0, 0, 0, 0);
          const dueDateNormalized = new Date(dueDate);
          dueDateNormalized.setHours(0, 0, 0, 0);

          let status: 'paid' | 'upcoming' | 'overdue';
          if (i === 0) {
            status = 'paid'; // First payment is always paid (made at checkout)
          } else if (dueDateNormalized < today) {
            status = 'overdue';
          } else {
            status = 'upcoming';
          }

          schedule.push({
            orderId: order.id,
            installmentNumber: i + 1,
            totalInstallments,
            amount,
            dueDate,
            status,
            orderTotal: order.total,
            items: order.items.map(item => item.name),
          });
        }
      }
    });

    return schedule.sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime());
  };

  const allPayments = generatePaymentSchedule();
  
  const filteredPayments = allPayments.filter(payment => {
    if (selectedFilter === 'all') return true;
    return payment.status === selectedFilter;
  });

  const upcomingPayments = allPayments.filter(p => p.status === 'upcoming');
  const paidPayments = allPayments.filter(p => p.status === 'paid');
  const overduePayments = allPayments.filter(p => p.status === 'overdue');

  const totalUpcoming = upcomingPayments.reduce((sum, p) => sum + p.amount, 0);
  const totalPaid = paidPayments.reduce((sum, p) => sum + p.amount, 0);

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'paid':
        return {
          icon: CheckCircle,
          color: 'text-green-600',
          bgColor: 'bg-green-100',
          label: 'Paid',
        };
      case 'upcoming':
        return {
          icon: Clock,
          color: 'text-blue-600',
          bgColor: 'bg-blue-100',
          label: 'Upcoming',
        };
      case 'overdue':
        return {
          icon: AlertCircle,
          color: 'text-red-600',
          bgColor: 'bg-red-100',
          label: 'Overdue',
        };
      default:
        return {
          icon: Clock,
          color: 'text-gray-600',
          bgColor: 'bg-gray-100',
          label: status,
        };
    }
  };

  const handlePayNow = (payment: PaymentInstallment) => {
    toast.success(`Payment of $${payment.amount.toFixed(2)} processed successfully!`);
  };

  if (allPayments.length === 0) {
    return (
      <div className="text-center py-12 max-w-md mx-auto">
        <DollarSign className="h-16 w-16 mx-auto text-gray-400 mb-4" />
        <h2 className="text-2xl font-bold mb-2">No Payment Plans</h2>
        <p className="text-gray-500 mb-6">
          You don't have any active payment plans. Place an order with a flexible payment option to see your payment schedule here.
        </p>
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6 text-left">
          <p className="font-semibold text-sm mb-2">How to create a payment plan:</p>
          <ol className="text-sm text-gray-700 space-y-1 list-decimal list-inside">
            <li>Add products to your cart</li>
            <li>Proceed to checkout</li>
            <li>Select a payment plan (Split in 2 Weeks, Pay Weekly, or Pay Monthly)</li>
            <li>Complete your order</li>
          </ol>
        </div>
        <Link to="/">
          <Button>
            <ShoppingCart className="h-4 w-4 mr-2" />
            Start Shopping
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Payment Schedule</h1>
        <p className="text-gray-500 mt-1">Track and manage your payment installments</p>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-500">Total Paid</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-3xl font-bold">${totalPaid.toFixed(2)}</p>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
            <p className="text-sm text-gray-500 mt-1">{paidPayments.length} payments</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-500">Upcoming Payments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-3xl font-bold">${totalUpcoming.toFixed(2)}</p>
              <Clock className="h-8 w-8 text-blue-500" />
            </div>
            <p className="text-sm text-gray-500 mt-1">{upcomingPayments.length} payments</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-500">Total Plans</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-3xl font-bold">{orders.filter(o => o.installments).length}</p>
              <Calendar className="h-8 w-8 text-purple-500" />
            </div>
            <p className="text-sm text-gray-500 mt-1">Active payment plans</p>
          </CardContent>
        </Card>
      </div>

      {overduePayments.length > 0 && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
              <div>
                <p className="font-semibold text-red-900">
                  You have {overduePayments.length} overdue payment{overduePayments.length > 1 ? 's' : ''}
                </p>
                <p className="text-sm text-red-700">
                  Total overdue: ${overduePayments.reduce((sum, p) => sum + p.amount, 0).toFixed(2)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Filter Buttons */}
      <div className="flex gap-2">
        <Button
          variant={selectedFilter === 'all' ? 'default' : 'outline'}
          onClick={() => setSelectedFilter('all')}
        >
          All ({allPayments.length})
        </Button>
        <Button
          variant={selectedFilter === 'upcoming' ? 'default' : 'outline'}
          onClick={() => setSelectedFilter('upcoming')}
        >
          Upcoming ({upcomingPayments.length})
        </Button>
        <Button
          variant={selectedFilter === 'paid' ? 'default' : 'outline'}
          onClick={() => setSelectedFilter('paid')}
        >
          Paid ({paidPayments.length})
        </Button>
      </div>

      {/* Payment Schedule */}
      <div className="space-y-4">
        {filteredPayments.map((payment, index) => {
          const statusConfig = getStatusConfig(payment.status);
          const StatusIcon = statusConfig.icon;
          const progress = ((payment.installmentNumber - 1) / payment.totalInstallments) * 100;

          return (
            <Card key={`${payment.orderId}-${index}`}>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {/* Header */}
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-lg">
                          Payment {payment.installmentNumber} of {payment.totalInstallments}
                        </h3>
                        <Badge className={`${statusConfig.bgColor} ${statusConfig.color}`}>
                          <StatusIcon className="h-3 w-3 mr-1" />
                          {statusConfig.label}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-500">Order #{payment.orderId}</p>
                    </div>
                    <div className="text-left md:text-right">
                      <p className="text-3xl font-bold">${payment.amount.toFixed(2)}</p>
                      <p className="text-sm text-gray-500">
                        Due: {format(payment.dueDate, 'MMM dd, yyyy')}
                      </p>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>Payment Progress</span>
                      <span>{payment.installmentNumber - 1} of {payment.totalInstallments} paid</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>

                  {/* Order Details */}
                  <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Order Total</span>
                      <span className="font-medium">${payment.orderTotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Items</span>
                      <span className="font-medium text-right max-w-[200px] truncate">
                        {payment.items.join(', ')}
                      </span>
                    </div>
                  </div>

                  {/* Action Button */}
                  {payment.status === 'upcoming' && (
                    <Button
                      className="w-full"
                      variant="outline"
                      onClick={() => handlePayNow(payment)}
                    >
                      Pay Now
                    </Button>
                  )}
                  {payment.status === 'overdue' && (
                    <Button
                      className="w-full"
                      variant="destructive"
                      onClick={() => handlePayNow(payment)}
                    >
                      Pay Overdue Amount
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredPayments.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No {selectedFilter} payments</p>
        </div>
      )}
    </div>
  );
}