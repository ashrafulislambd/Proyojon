import { useParams, Link, useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { ShoppingCart, ArrowLeft, Store } from 'lucide-react';
import { toast } from 'sonner';

export function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { products, addToCart } = useApp();
  
  const product = products.find(p => p.id === id);

  if (!product) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Product not found</h2>
        <Link to="/">
          <Button>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Shop
          </Button>
        </Link>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(product);
    toast.success(`${product.name} added to cart`);
  };

  const paymentOptions = [
    { label: 'Pay in Full', amount: product.price },
    { label: 'Split in 2 weeks', amount: product.price / 2, period: '2 payments' },
    { label: 'Pay monthly (4 weeks)', amount: product.price / 4, period: '4 weekly payments' },
    { label: 'Pay in 3 months', amount: product.price / 3, period: '3 monthly payments' },
  ];

  return (
    <div className="space-y-6">
      <Button variant="ghost" onClick={() => navigate(-1)}>
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back
      </Button>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Product Image */}
        <div className="space-y-4">
          <div className="aspect-square overflow-hidden rounded-lg bg-gray-100">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          <div>
            <div className="flex items-start justify-between gap-4 mb-2">
              <h1 className="text-3xl font-bold">{product.name}</h1>
              <Badge variant="secondary" className="text-sm">
                {product.category}
              </Badge>
            </div>
            <div className="flex items-center gap-2 text-gray-500 mb-4">
              <Store className="h-4 w-4" />
              <span className="text-sm">Sold by {product.seller}</span>
            </div>
            <p className="text-gray-600 leading-relaxed">{product.description}</p>
          </div>

          <div className="border-t border-b py-4">
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-4xl font-bold">${product.price.toFixed(2)}</span>
              <span className="text-gray-500">or as low as</span>
            </div>
            <p className="text-2xl font-semibold text-blue-600">
              ${(product.price / 4).toFixed(2)}/week
            </p>
          </div>

          <div className="space-y-3">
            <p className="text-sm font-medium text-gray-700">Stock Availability</p>
            <div className="flex items-center gap-2">
              <div className={`h-3 w-3 rounded-full ${product.stock > 50 ? 'bg-green-500' : product.stock > 0 ? 'bg-yellow-500' : 'bg-red-500'}`} />
              <span className="text-sm">
                {product.stock > 50 ? 'In Stock' : product.stock > 0 ? `Only ${product.stock} left` : 'Out of Stock'}
              </span>
            </div>
          </div>

          <div className="space-y-3">
            <Button
              onClick={handleAddToCart}
              size="lg"
              className="w-full"
              disabled={product.stock === 0}
            >
              <ShoppingCart className="h-5 w-5 mr-2" />
              Add to Cart
            </Button>
            <Link to="/cart" className="block">
              <Button variant="outline" size="lg" className="w-full">
                Go to Cart
              </Button>
            </Link>
          </div>

          {/* Payment Options */}
          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold mb-4">Flexible Payment Options</h3>
              <div className="space-y-3">
                {paymentOptions.map((option, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div>
                      <p className="font-medium">{option.label}</p>
                      {option.period && (
                        <p className="text-xs text-gray-500">{option.period}</p>
                      )}
                    </div>
                    <p className="font-bold text-lg">${option.amount.toFixed(2)}</p>
                  </div>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-4 text-center">
                0% interest · No hidden fees
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
