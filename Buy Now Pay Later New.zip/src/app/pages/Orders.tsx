import { useApp } from '../context/AppContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Package, Calendar, DollarSign, CreditCard } from 'lucide-react';
import { format } from 'date-fns';
import { Link } from 'react-router';
import { Button } from '../components/ui/button';

export function Orders() {
  const { orders } = useApp();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getPlanLabel = (plan: string) => {
    switch (plan) {
      case 'full':
        return 'Paid in Full';
      case '2weeks':
        return 'Split in 2 Weeks';
      case '1month':
        return 'Weekly Payments';
      case '3months':
        return 'Monthly Payments';
      default:
        return plan;
    }
  };

  const hasInstallmentOrders = orders.some(order => order.installments);

  if (orders.length === 0) {
    return (
      <div className="text-center py-12">
        <Package className="h-16 w-16 mx-auto text-gray-400 mb-4" />
        <h2 className="text-2xl font-bold mb-2">No orders yet</h2>
        <p className="text-gray-500">Your order history will appear here</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">My Orders</h1>
          <p className="text-gray-500 mt-1">Track and manage your orders</p>
        </div>
        {hasInstallmentOrders && (
          <Link to="/repayments">
            <Button variant="outline">
              <CreditCard className="h-4 w-4 mr-2" />
              View Payment Schedule
            </Button>
          </Link>
        )}
      </div>

      <div className="space-y-4">
        {orders.map(order => (
          <Card key={order.id}>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <CardTitle className="text-lg">Order #{order.id}</CardTitle>
                    <Badge className={getStatusColor(order.status)}>
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {format(new Date(order.date), 'MMM dd, yyyy')}
                    </span>
                    <span className="flex items-center gap-1">
                      <DollarSign className="h-4 w-4" />
                      {getPlanLabel(order.paymentPlan)}
                    </span>
                  </div>
                </div>
                <div className="text-left md:text-right">
                  <p className="text-2xl font-bold">${order.total.toFixed(2)}</p>
                  {order.installments && (
                    <p className="text-sm text-gray-500">
                      ${order.installments.amount.toFixed(2)} {order.installments.frequency}
                    </p>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Order Items */}
                <div className="space-y-3">
                  {order.items.map(item => (
                    <div key={item.id} className="flex items-center gap-4 pb-3 border-b last:border-b-0">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-16 h-16 object-cover rounded"
                      />
                      <div className="flex-1">
                        <p className="font-medium">{item.name}</p>
                        <p className="text-sm text-gray-500">
                          Quantity: {item.quantity} × ${item.price.toFixed(2)}
                        </p>
                      </div>
                      <p className="font-semibold">
                        ${(item.price * item.quantity).toFixed(2)}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Payment Info */}
                {order.installments && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <p className="font-semibold text-sm mb-2">Payment Schedule</p>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-gray-600">Amount</p>
                        <p className="font-semibold">${order.installments.amount.toFixed(2)}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Frequency</p>
                        <p className="font-semibold capitalize">{order.installments.frequency}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Remaining</p>
                        <p className="font-semibold">{order.installments.remaining} payments</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}