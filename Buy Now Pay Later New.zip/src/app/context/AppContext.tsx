import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  brand: string;
  image: string;
  seller: string;
  stock: number;
  bnplEligible: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  zipCode: string;
  kycVerified: boolean;
  emailVerified: boolean;
  phoneVerified: boolean;
  creditScore: number;
  documents: {
    id: string;
    type: string;
    url: string;
    uploadedAt: string;
  }[];
}

export interface Merchant {
  id: string;
  businessName: string;
  email: string;
  phone: string;
  address: string;
  verified: boolean;
  verificationDate?: string;
  totalSales: number;
  pendingSettlement: number;
  settlements: Settlement[];
}

export interface Settlement {
  id: string;
  merchantId: string;
  amount: number;
  date: string;
  status: 'pending' | 'completed';
  orders: string[];
}

export interface Notification {
  id: string;
  userId: string;
  type: 'payment_reminder' | 'payment_success' | 'payment_failed' | 'plan_change' | 'late_fee';
  title: string;
  message: string;
  date: string;
  read: boolean;
}

export interface Transaction {
  id: string;
  orderId: string;
  amount: number;
  type: 'payment' | 'refund' | 'late_fee';
  status: 'completed' | 'pending' | 'failed';
  date: string;
  paymentMethod: string;
  receipt?: string;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  paymentPlan: 'full' | '3months' | '6months' | '12months';
  status: 'pending' | 'processing' | 'completed';
  date: string;
  installments?: {
    amount: number;
    frequency: string;
    remaining: number;
    totalInstallments: number;
    interestRate: number;
    firstPaymentDate: string;
    lateFee: number;
  };
  eligibilityChecked: boolean;
  creditScoreUsed: number;
  outstandingBalance: number;
  transactions: Transaction[];
}

interface AppContextType {
  // User
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  updateUserProfile: (updates: Partial<User>) => void;
  uploadDocument: (type: string, url: string) => void;
  
  // Merchants
  merchants: Merchant[];
  addMerchant: (merchant: Omit<Merchant, 'id' | 'verified' | 'totalSales' | 'pendingSettlement' | 'settlements'>) => void;
  verifyMerchant: (merchantId: string) => void;
  settlements: Settlement[];
  processMerchantSettlement: (merchantId: string) => void;
  
  // Products
  products: Product[];
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  
  // Cart
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  
  // Orders
  orders: Order[];
  createOrder: (paymentPlan: Order['paymentPlan']) => void;
  
  // Payments
  makePayment: (orderId: string, amount: number) => void;
  transactions: Transaction[];
  
  // Notifications
  notifications: Notification[];
  markNotificationAsRead: (notificationId: string) => void;
  addNotification: (notification: Omit<Notification, 'id' | 'date' | 'read'>) => void;
  
  // User Role
  userRole: 'buyer' | 'seller' | 'admin';
  setUserRole: (role: 'buyer' | 'seller' | 'admin') => void;
  
  // Admin
  isAdmin: boolean;
  allUsers: User[];
  auditLogs: AuditLog[];
}

export interface AuditLog {
  id: string;
  action: string;
  userId: string;
  userName: string;
  timestamp: string;
  details: string;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const INITIAL_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Organic Bananas',
    description: 'Fresh organic bananas, rich in potassium and perfect for a healthy snack.',
    price: 2.99,
    category: 'Fruits',
    brand: 'FreshFarm',
    image: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=500&h=500&fit=crop',
    seller: 'Fresh Farm Co.',
    stock: 150,
    bnplEligible: true
  },
  {
    id: '2',
    name: 'Fresh Milk',
    description: 'Farm fresh whole milk, pasteurized and packed with nutrients.',
    price: 3.49,
    category: 'Dairy',
    brand: 'DairyGold',
    image: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=500&h=500&fit=crop',
    seller: 'Dairy Delights',
    stock: 80,
    bnplEligible: true
  },
  {
    id: '3',
    name: 'Whole Wheat Bread',
    description: 'Freshly baked whole wheat bread, perfect for sandwiches and toast.',
    price: 4.99,
    category: 'Bakery',
    brand: 'BreadCo',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=500&h=500&fit=crop',
    seller: 'Artisan Bakery',
    stock: 45,
    bnplEligible: true
  },
  {
    id: '4',
    name: 'Free Range Eggs',
    description: 'Farm fresh free-range eggs, packed with protein and vitamins.',
    price: 5.99,
    category: 'Dairy',
    brand: 'HappyHens',
    image: 'https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f?w=500&h=500&fit=crop',
    seller: 'Happy Hens Farm',
    stock: 120,
    bnplEligible: true
  },
  {
    id: '5',
    name: 'Organic Tomatoes',
    description: 'Vine-ripened organic tomatoes, perfect for salads and cooking.',
    price: 3.99,
    category: 'Vegetables',
    brand: 'GreenValley',
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=500&h=500&fit=crop',
    seller: 'Green Valley Farm',
    stock: 200,
    bnplEligible: true
  },
  {
    id: '6',
    name: 'Fresh Spinach',
    description: 'Crisp and fresh organic spinach, packed with iron and vitamins.',
    price: 2.49,
    category: 'Vegetables',
    brand: 'OrganicGreens',
    image: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=500&h=500&fit=crop',
    seller: 'Organic Greens',
    stock: 90,
    bnplEligible: true
  },
  {
    id: '7',
    name: 'Cheddar Cheese',
    description: 'Sharp aged cheddar cheese, perfect for snacking or cooking.',
    price: 6.99,
    category: 'Dairy',
    brand: 'CheeseWorks',
    image: 'https://images.unsplash.com/photo-1618164436241-4473940d1f5c?w=500&h=500&fit=crop',
    seller: 'Dairy Delights',
    stock: 60,
    bnplEligible: true
  },
  {
    id: '8',
    name: 'Red Apples',
    description: 'Crisp and sweet red apples, perfect for snacking or baking.',
    price: 4.49,
    category: 'Fruits',
    brand: 'OrchardFresh',
    image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=500&h=500&fit=crop',
    seller: 'Orchard Fresh',
    stock: 180,
    bnplEligible: true
  },
  // Electronics
  {
    id: '9',
    name: 'Dell XPS 15 Laptop',
    description: '15.6" laptop with Intel i7, 16GB RAM, 512GB SSD. Perfect for work and gaming.',
    price: 1299.99,
    category: 'Electronics',
    brand: 'Dell',
    image: 'https://images.unsplash.com/photo-1759668358660-0d06064f0f84?w=500&h=500&fit=crop',
    seller: 'TechHub',
    stock: 25,
    bnplEligible: true
  },
  {
    id: '10',
    name: 'Samsung Galaxy S24',
    description: 'Latest smartphone with 256GB storage, 5G capable, stunning AMOLED display.',
    price: 899.99,
    category: 'Electronics',
    brand: 'Samsung',
    image: 'https://images.unsplash.com/photo-1761645446921-27d641efa0b5?w=500&h=500&fit=crop',
    seller: 'TechHub',
    stock: 40,
    bnplEligible: true
  },
  {
    id: '11',
    name: 'Sony WH-1000XM5 Headphones',
    description: 'Premium noise-canceling wireless headphones with 30-hour battery life.',
    price: 349.99,
    category: 'Electronics',
    brand: 'Sony',
    image: 'https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?w=500&h=500&fit=crop',
    seller: 'AudioWorld',
    stock: 60,
    bnplEligible: true
  },
  {
    id: '12',
    name: 'LG 55" 4K Smart TV',
    description: '55-inch 4K OLED TV with HDR, webOS, and built-in streaming apps.',
    price: 1499.99,
    category: 'Electronics',
    brand: 'LG',
    image: 'https://images.unsplash.com/photo-1593784991095-a205069470b6?w=500&h=500&fit=crop',
    seller: 'TechHub',
    stock: 20,
    bnplEligible: true
  },
  // Furniture
  {
    id: '13',
    name: 'Modern Gray Sofa',
    description: '3-seater comfortable sofa with washable covers. Perfect for living room.',
    price: 799.99,
    category: 'Furniture',
    brand: 'HomeComfort',
    image: 'https://images.unsplash.com/photo-1656869929510-216b4976f854?w=500&h=500&fit=crop',
    seller: 'Furniture Depot',
    stock: 15,
    bnplEligible: true
  },
  {
    id: '14',
    name: 'Ergonomic Office Chair',
    description: 'Adjustable office chair with lumbar support and breathable mesh.',
    price: 299.99,
    category: 'Furniture',
    brand: 'ErgoMaster',
    image: 'https://images.unsplash.com/photo-1600065428205-b3fb0bd02b3b?w=500&h=500&fit=crop',
    seller: 'Office Plus',
    stock: 35,
    bnplEligible: true
  },
  {
    id: '15',
    name: 'Queen Size Platform Bed',
    description: 'Modern platform bed frame with storage drawers. Easy assembly.',
    price: 599.99,
    category: 'Furniture',
    brand: 'SleepWell',
    image: 'https://images.unsplash.com/photo-1640003145136-f998284e11de?w=500&h=500&fit=crop',
    seller: 'Furniture Depot',
    stock: 18,
    bnplEligible: true
  },
  // Clothing
  {
    id: '16',
    name: 'Men\'s Leather Jacket',
    description: 'Genuine leather jacket with classic style. Available in multiple sizes.',
    price: 249.99,
    category: 'Clothing',
    brand: 'UrbanStyle',
    image: 'https://images.unsplash.com/photo-1611312449408-fcece27cdbb7?w=500&h=500&fit=crop',
    seller: 'Fashion Store',
    stock: 45,
    bnplEligible: true
  },
  {
    id: '17',
    name: 'Women\'s Slim Fit Jeans',
    description: 'Comfortable stretch denim jeans in classic blue. High-waisted fit.',
    price: 79.99,
    category: 'Clothing',
    brand: 'DenimCo',
    image: 'https://images.unsplash.com/photo-1609831190577-04538764f438?w=500&h=500&fit=crop',
    seller: 'Fashion Store',
    stock: 80,
    bnplEligible: true
  },
  {
    id: '18',
    name: 'Running Sneakers Pro',
    description: 'High-performance running shoes with cushioned sole and arch support.',
    price: 129.99,
    category: 'Clothing',
    brand: 'SportMax',
    image: 'https://images.unsplash.com/photo-1760302318631-a8d342cd4951?w=500&h=500&fit=crop',
    seller: 'Sports World',
    stock: 100,
    bnplEligible: true
  },
  // Appliances
  {
    id: '19',
    name: 'Smart Refrigerator',
    description: 'French door refrigerator with WiFi, touchscreen, and ice maker.',
    price: 1899.99,
    category: 'Appliances',
    brand: 'Samsung',
    image: 'https://images.unsplash.com/photo-1758488438758-5e2eedf769ce?w=500&h=500&fit=crop',
    seller: 'Appliance Center',
    stock: 12,
    bnplEligible: true
  },
  {
    id: '20',
    name: 'Front Load Washing Machine',
    description: 'Energy-efficient washing machine with 15 wash cycles and steam clean.',
    price: 699.99,
    category: 'Appliances',
    brand: 'LG',
    image: 'https://images.unsplash.com/photo-1624381987697-3f93d65ddeea?w=500&h=500&fit=crop',
    seller: 'Appliance Center',
    stock: 22,
    bnplEligible: true
  }
];

const DEFAULT_USER: User = {
  id: 'user1',
  name: 'John Doe',
  email: 'john.doe@example.com',
  phone: '+1234567890',
  address: '123 Main Street',
  city: 'New York',
  zipCode: '10001',
  kycVerified: true,
  emailVerified: true,
  phoneVerified: true,
  creditScore: 720,
  documents: []
};

export function AppProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('bnpl_current_user');
    return saved ? JSON.parse(saved) : DEFAULT_USER;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('bnpl_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('bnpl_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('bnpl_orders');
    return saved ? JSON.parse(saved) : [];
  });

  const [merchants, setMerchants] = useState<Merchant[]>(() => {
    const saved = localStorage.getItem('bnpl_merchants');
    return saved ? JSON.parse(saved) : [];
  });

  const [settlements, setSettlements] = useState<Settlement[]>(() => {
    const saved = localStorage.getItem('bnpl_settlements');
    return saved ? JSON.parse(saved) : [];
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('bnpl_transactions');
    return saved ? JSON.parse(saved) : [];
  });

  const [notifications, setNotifications] = useState<Notification[]>(() => {
    const saved = localStorage.getItem('bnpl_notifications');
    return saved ? JSON.parse(saved) : [];
  });

  const [allUsers] = useState<User[]>([DEFAULT_USER]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const saved = localStorage.getItem('bnpl_audit_logs');
    return saved ? JSON.parse(saved) : [];
  });

  const [userRole, setUserRole] = useState<'buyer' | 'seller' | 'admin'>('buyer');
  const isAdmin = userRole === 'admin';

  // Persist data
  useEffect(() => {
    localStorage.setItem('bnpl_current_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('bnpl_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('bnpl_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('bnpl_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('bnpl_merchants', JSON.stringify(merchants));
  }, [merchants]);

  useEffect(() => {
    localStorage.setItem('bnpl_settlements', JSON.stringify(settlements));
  }, [settlements]);

  useEffect(() => {
    localStorage.setItem('bnpl_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('bnpl_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('bnpl_audit_logs', JSON.stringify(auditLogs));
  }, [auditLogs]);

  // Audit log helper
  const addAuditLog = (action: string, details: string) => {
    const log: AuditLog = {
      id: Date.now().toString(),
      action,
      userId: currentUser?.id || 'unknown',
      userName: currentUser?.name || 'Unknown User',
      timestamp: new Date().toISOString(),
      details
    };
    setAuditLogs(prev => [log, ...prev]);
  };

  // User functions
  const updateUserProfile = (updates: Partial<User>) => {
    if (currentUser) {
      const updated = { ...currentUser, ...updates };
      setCurrentUser(updated);
      addAuditLog('UPDATE_PROFILE', `User ${currentUser.name} updated profile`);
    }
  };

  const uploadDocument = (type: string, url: string) => {
    if (currentUser) {
      const doc = {
        id: Date.now().toString(),
        type,
        url,
        uploadedAt: new Date().toISOString()
      };
      const updated = {
        ...currentUser,
        documents: [...currentUser.documents, doc]
      };
      setCurrentUser(updated);
      addAuditLog('UPLOAD_DOCUMENT', `User ${currentUser.name} uploaded ${type}`);
    }
  };

  // Merchant functions
  const addMerchant = (merchant: Omit<Merchant, 'id' | 'verified' | 'totalSales' | 'pendingSettlement' | 'settlements'>) => {
    const newMerchant: Merchant = {
      ...merchant,
      id: Date.now().toString(),
      verified: false,
      totalSales: 0,
      pendingSettlement: 0,
      settlements: []
    };
    setMerchants(prev => [...prev, newMerchant]);
    addAuditLog('ADD_MERCHANT', `Merchant ${merchant.businessName} added`);
  };

  const verifyMerchant = (merchantId: string) => {
    setMerchants(prev =>
      prev.map(m =>
        m.id === merchantId
          ? { ...m, verified: true, verificationDate: new Date().toISOString() }
          : m
      )
    );
    addAuditLog('VERIFY_MERCHANT', `Merchant ${merchantId} verified`);
  };

  const processMerchantSettlement = (merchantId: string) => {
    const merchant = merchants.find(m => m.id === merchantId);
    if (merchant && merchant.pendingSettlement > 0) {
      const settlement: Settlement = {
        id: Date.now().toString(),
        merchantId,
        amount: merchant.pendingSettlement,
        date: new Date().toISOString(),
        status: 'completed',
        orders: []
      };
      setSettlements(prev => [settlement, ...prev]);
      setMerchants(prev =>
        prev.map(m =>
          m.id === merchantId
            ? { ...m, pendingSettlement: 0, settlements: [settlement, ...m.settlements] }
            : m
        )
      );
      addAuditLog('PROCESS_SETTLEMENT', `Settlement of $${merchant.pendingSettlement} processed for merchant ${merchantId}`);
    }
  };

  // Product functions
  const addProduct = (product: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...product,
      id: Date.now().toString(),
    };
    setProducts(prev => [...prev, newProduct]);
    addAuditLog('ADD_PRODUCT', `Product ${product.name} added`);
  };

  const updateProduct = (id: string, updatedProduct: Partial<Product>) => {
    setProducts(prev =>
      prev.map(p => (p.id === id ? { ...p, ...updatedProduct } : p))
    );
    addAuditLog('UPDATE_PRODUCT', `Product ${id} updated`);
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
    addAuditLog('DELETE_PRODUCT', `Product ${id} deleted`);
  };

  // Cart functions
  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  // Order functions
  const createOrder = (paymentPlan: Order['paymentPlan']) => {
    if (!currentUser) return;

    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    
    // Eligibility check based on credit score and order amount
    const eligibilityChecked = currentUser.creditScore >= 600 && total <= 5000;
    
    let installments;
    if (paymentPlan !== 'full') {
      const plans = {
        '3months': { count: 3, frequency: 'monthly', interestRate: 0 },
        '6months': { count: 6, frequency: 'monthly', interestRate: 5 },
        '12months': { count: 12, frequency: 'monthly', interestRate: 10 }
      };
      const plan = plans[paymentPlan];
      const interest = (total * plan.interestRate) / 100;
      const totalWithInterest = total + interest;
      
      const firstPaymentDate = new Date();
      firstPaymentDate.setMonth(firstPaymentDate.getMonth() + 1);
      
      installments = {
        amount: totalWithInterest / plan.count,
        frequency: plan.frequency,
        remaining: plan.count,
        totalInstallments: plan.count,
        interestRate: plan.interestRate,
        firstPaymentDate: firstPaymentDate.toISOString(),
        lateFee: 25
      };
    }

    const newOrder: Order = {
      id: Date.now().toString(),
      userId: currentUser.id,
      items: [...cart],
      total,
      paymentPlan,
      status: 'pending',
      date: new Date().toISOString(),
      installments,
      eligibilityChecked,
      creditScoreUsed: currentUser.creditScore,
      outstandingBalance: installments ? installments.amount * installments.remaining : 0,
      transactions: []
    };

    // Create initial transaction
    const initialTransaction: Transaction = {
      id: Date.now().toString(),
      orderId: newOrder.id,
      amount: paymentPlan === 'full' ? total : installments!.amount,
      type: 'payment',
      status: 'completed',
      date: new Date().toISOString(),
      paymentMethod: 'Credit Card',
      receipt: `RCPT-${Date.now()}`
    };

    setOrders(prev => [newOrder, ...prev]);
    setTransactions(prev => [initialTransaction, ...prev]);
    addAuditLog('CREATE_ORDER', `Order ${newOrder.id} created for $${total}`);
    
    // Add success notification
    addNotification({
      userId: currentUser.id,
      type: 'payment_success',
      title: 'Order Placed Successfully',
      message: `Your order #${newOrder.id} has been placed successfully.`
    });
    
    clearCart();
  };

  // Payment functions
  const makePayment = (orderId: string, amount: number) => {
    const transaction: Transaction = {
      id: Date.now().toString(),
      orderId,
      amount,
      type: 'payment',
      status: 'completed',
      date: new Date().toISOString(),
      paymentMethod: 'Credit Card',
      receipt: `RCPT-${Date.now()}`
    };

    setTransactions(prev => [transaction, ...prev]);
    
    // Update order outstanding balance
    setOrders(prev =>
      prev.map(order =>
        order.id === orderId
          ? { ...order, outstandingBalance: Math.max(0, order.outstandingBalance - amount) }
          : order
      )
    );

    addAuditLog('MAKE_PAYMENT', `Payment of $${amount} made for order ${orderId}`);
    
    if (currentUser) {
      addNotification({
        userId: currentUser.id,
        type: 'payment_success',
        title: 'Payment Successful',
        message: `Your payment of $${amount.toFixed(2)} has been processed successfully.`
      });
    }
  };

  // Notification functions
  const addNotification = (notification: Omit<Notification, 'id' | 'date' | 'read'>) => {
    const newNotification: Notification = {
      ...notification,
      id: Date.now().toString(),
      date: new Date().toISOString(),
      read: false
    };
    setNotifications(prev => [newNotification, ...prev]);
  };

  const markNotificationAsRead = (notificationId: string) => {
    setNotifications(prev =>
      prev.map(n => (n.id === notificationId ? { ...n, read: true } : n))
    );
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        updateUserProfile,
        uploadDocument,
        merchants,
        addMerchant,
        verifyMerchant,
        settlements,
        processMerchantSettlement,
        products,
        addProduct,
        updateProduct,
        deleteProduct,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        orders,
        createOrder,
        makePayment,
        transactions,
        notifications,
        markNotificationAsRead,
        addNotification,
        userRole,
        setUserRole,
        isAdmin,
        allUsers,
        auditLogs,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}